import React from "react";
import {
  StyleSheet,
  Text,
  View,
  ImageBackground,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
  Touchable,
  ScrollView,
} from "react-native";
import { useNavigation, useTheme } from "@react-navigation/native";
import TopNav from "../components/topnav";
import BottomNav from "../components/BottomNav";
import { Dimensions } from "react-native";
import {
  LineChart,
  BarChart,
  PieChart,
  ProgressChart,
  ContributionGraph,
  StackedBarChart,
} from "react-native-chart-kit";

const MoodReport = () => {
  const screenWidth = Dimensions.get("window").width;
  const navigation = useNavigation();
  const { colors } = useTheme();
  const data = {
    labels: ["January", "February", "March", "April", "May", "June"],
    datasets: [
      {
        data: [20, 45, 28, 80, 99, 43],
        color: (opacity = 1) => `rgba(134, 65, 244, ${opacity})`, // optional
        strokeWidth: 2, // optional
      },
    ],
    legend: ["Rainy Days"], // optional
  };
  const data2 = {
    labels: ["Swim", "Bike", "Run"], // optional
    data: [0.4, 0.6, 0.8],
    colors: ["red", "yellow", "blue"],
  };
  const chartConfig = {
    backgroundGradientFromOpacity: 0.5,
    backgroundGradientToOpacity: 1,
    backgroundColor: "white",
    backgroundGradientFrom: "white",
    backgroundGradientTo: "white",
    propsForLabels: { fill: colors.text },
    decimalPlaces: 2,
    color: (opacity = 1, _index) => `rgba(255,255,255,${opacity})`,
  };
  const commitsData = [
    { week: "1", count: 10 },
    { week: "3", count: 9 },
    { week: "4", count: 3 },
    { week: "5", count: 4 },
    { week: "6", count: 5 },
    { week: "0", count: 2 },
    { week: "1", count: 3 },
    { week: "1", count: 2 },
    { week: "2", count: 4 },
    { week: "5", count: 2 },
    { week: "0", count: 4 },
  ];
  return (
    <View style={styles.moodreprt}>
      <TopNav />
      <View style={styles.scroll}>
        <ScrollView>
          <View
            style={{
              paddingTop: 0,
              zIndex: 10,
            }}
          >
            <View style={styles.lingraph}>
              <Text style={styles.title}>Your weekly report</Text>
              <LineChart
                data={data}
                width={Dimensions.get("window").width}
                height={220}
                yAxisLabel="$"
                yAxisSuffix="k"
                yAxisInterval={1} // optional, defaults to 1
                chartConfig={{
                  backgroundColor: "white",
                  backgroundGradientFrom: "white",
                  backgroundGradientTo: "white",
                  decimalPlaces: 2, // optional, defaults to 2dp
                  color: (opacity = 1) => `rgba(0, 64, 255, ${opacity})`,
                  labelColor: (opacity = 1) => `rgba(0, 64, 255, ${opacity})`,
                  style: {
                    borderRadius: 16,
                  },
                  propsForDots: {
                    r: "6",
                    strokeWidth: "2",
                    stroke: "#4000ff",
                  },
                }}
                bezier
                style={{
                  marginVertical: 8,
                  borderRadius: 10,
                  paddingBottom: 10,
                }}
              />
              <ProgressChart
                data={data2}
                width={screenWidth}
                height={220}
                strokeWidth={16}
                radius={32}
                chartConfig={chartConfig}
                hideLegend={false}
                style={{}}
                withCustomBarColorFromData={true}
              />
              <Text style={styles.title}>
                Month in pixels : {new Date().getMonth() + 1}
              </Text>
              <ContributionGraph
                values={commitsData}
                endDate={"10"}
                numDays={30}
                width={screenWidth}
                height={220}
                showMonthLabels={false}
                gutterSize={23}
                horizontal={false}
                chartConfig={{
                  backgroundGradientFrom: "white",
                  backgroundGradientFromOpacity: 0.5,
                  backgroundGradientTo: "white",
                  backgroundGradientToOpacity: 1,
                  color: (opacity = 1) => `rgba(100, 100, 26, ${opacity})`,
                  strokeWidth: 2, // optional, default 3
                  barPercentage: 0.5,
                  useShadowColorFromDataset: false, // optional

                  propsForLabels: { fill: colors.text },
                }}
              />
            </View>
          </View>
        </ScrollView>
        <BottomNav />
      </View>
    </View>
  );
};

export default MoodReport;

const styles = StyleSheet.create({
  moodreprt: {
    paddingTop: 15,
    flex: 1,
  },
  title: {
    fontWeight: "bold",
    alignSelf: "center",
    fontSize: 25,
    backgroundColor: "white",
    paddingLeft: 85,
    paddingRight: 85,
    paddingTop: 5,
  },
  lingraph: {
    paddingBottom: 150,
  },
  scroll: {
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    // flex:1,
    // flexBasis:570,
    // flexGrow:0
  },
});
